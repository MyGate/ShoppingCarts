<?php

//	Copyright 2012 MyGate

define('MODULE_PAYMENT_MYGATE_ADMIN_TITLE','MyGate');
define('MODULE_PAYMENT_MYGATE_CATALOG_TITLE','Pay with MyGate');
define('MODULE_PAYMENT_MYGATE_DESCRIPTION','<img src="images/icon_popup.gif" />&nbsp;<a href="http://mygate.co.za/products/payment-gateway" style="font-weight:bold;text-decoration:underline;" target="_blank">Visit the MyGate Website</a>');