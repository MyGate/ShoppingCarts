<?php

//	Copyright 2012 MyGate

//	Create MyGate Class
class mygate extends base {
//	Create Constructor Function
function mygate() {
    global $order;
	//	Create Module Settings
	$this->enabled = (MODULE_PAYMENT_MYGATE_STATUS == 'Yes') ? true : false;
	$this->code = 'mygate';
	//	Create MyGate Settings
	if(IS_ADMIN_FLAG === true)
		$this->title = MODULE_PAYMENT_MYGATE_ADMIN_TITLE;
	else
		$this->title = MODULE_PAYMENT_MYGATE_CATALOG_TITLE;
	$this->description = MODULE_PAYMENT_MYGATE_DESCRIPTION;
	$this->sort_order = MODULE_PAYMENT_MYGATE_SORT;
	$this->order_status = 2;
	$this->form_action_url = 'https://www.mygate.co.za/virtual/8x0x0/dsp_ecommercepaymentparent.cfm';
	$this->gateway_mode = 'offsite';
	//	Create Tables
	$this->t = TABLE_CONFIGURATION;
	$this->o = TABLE_ORDERS_STATUS_HISTORY;
}
//	Create Check Function
function check() {
	global $db;
	if(!$this->_check) {
		$check = $db->Execute("SELECT configuration_value FROM $this->t WHERE configuration_key = 'MODULE_PAYMENT_MYGATE_STATUS'");
		$this->_check = $check->RecordCount();
	}
	return $this->_check;
}
//	Create Install Function
function install() {
	global $db;
	$rows[] = array(
		'configuration_title'=>'Enabled?',
		'configuration_key'=>'MODULE_PAYMENT_MYGATE_STATUS',
		'configuration_value'=>'Yes',
		'configuration_description'=>'Select "Yes" to start accepting payments with your MyGate Account.',
		'configuration_group_id'=>'6',
		'sort_order'=>'0',
		'set_function'=>'zen_cfg_select_option(array(\"Yes\", \"No\"), '
	);
	$rows[] = array(
		'configuration_title'=>'Test Mode?',
		'configuration_key'=>'MODULE_PAYMENT_MYGATE_MODE',
		'configuration_value'=>'Yes',
		'configuration_description'=>'Select "Yes" to process transaction in Test Mode.',
		'configuration_group_id'=>'6',
		'sort_order'=>'0',
		'set_function'=>'zen_cfg_select_option(array(\"Yes\", \"No\"), '
	);
	$rows[] = array(
		'configuration_title'=>'MyGate Merchant ID',
		'configuration_key'=>'MODULE_PAYMENT_MYGATE_MID',
		'configuration_description'=>'Type the "Merchant ID" allocated to you by MyGate.',
		'configuration_group_id'=>'6',
		'sort_order'=>'0'
	);
	$rows[] = array(
		'configuration_title'=>'MyGate Application ID',
		'configuration_key'=>'MODULE_PAYMENT_MYGATE_AID',
		'configuration_description'=>'Type the "Application ID" allocated to you by MyGate.',
		'configuration_group_id'=>'6',
		'sort_order'=>'0'
	);
	$rows[] = array(
		'configuration_title'=>'Sort Order',
		'configuration_key'=>'MODULE_PAYMENT_MYGATE_SORT',
		'configuration_value'=>'0',
		'configuration_description'=>'Type the "Sort Order" of MyGate in relation to other Payment Gateways.',
		'configuration_group_id'=>'6',
		'sort_order'=>'0'
	);
	foreach($rows as $row) {
		$f = implode(", ",array_keys($row));
		$v = implode("', '",array_values($row));
		$db->Execute("INSERT INTO $this->t ($f) VALUES ('$v')");
	}
}
//	Create Keys Function
function keys() {
	return array('MODULE_PAYMENT_MYGATE_STATUS','MODULE_PAYMENT_MYGATE_MODE','MODULE_PAYMENT_MYGATE_MID','MODULE_PAYMENT_MYGATE_AID','MODULE_PAYMENT_MYGATE_SORT');
}
//	Create Remove Function
function remove() {
	global $db;
	$db->Execute("DELETE FROM $this->t WHERE configuration_key LIKE '%MYGATE%'");
}
//	Create Process Button
function process_button() {
	global $order;
	//	Create Variables
	if(MODULE_PAYMENT_MYGATE_MODE == 'Yes') {
		$mode = '0';
		$merchant = '79958a8d-0c7b-4038-8e2e-8948e1d678e1';
		$application = 'd48750f9-1dc0-4290-a94c-9a1c9f7e2fb1';
	} else {
		$mode = '1';
		$merchant = MODULE_PAYMENT_MYGATE_MID;
		$application = MODULE_PAYMENT_MYGATE_AID;
	}
	$reference = sprintf("%010d",$_SESSION['customer_id']);
	$price = number_format($order->info['total'],2,'.','');
	$currency = 'ZAR';
	$surl = zen_href_link(FILENAME_CHECKOUT_PROCESS,'','SSL',false);
	$furl = zen_href_link(FILENAME_CHECKOUT_PROCESS,'','SSL',false);
	//	Create POST
	$post = array(
		'Mode'=>$mode,
		'txtMerchantID'=>$merchant,
		'txtApplicationID'=>$application,
		'txtMerchantReference'=>$reference,
		'txtPrice'=>$price,
		'txtCurrencyCode'=>$currency,
		'txtRedirectSuccessfulURL'=>$surl,
		'txtRedirectFailedURL'=>$furl
	);
	//	Create Fields
	foreach($post as $k=>$v)
		$button.= zen_draw_hidden_field($k,$v);
	//	Return Button
	return $button;
}
//	Capture Payment
function before_process() {
	global $order,$messageStack;
	//	Extract $_POST
	extract($_POST);
	//	Check $_RESULT
	$total = number_format($order->info['total'],2,'.','');
	if($_RESULT > -1) {
		if($TXTPRICE == $total)
			return;
		else {
			$messageStack->add_session('checkout_payment','Payment Details were altered before being sent to MyGate','error');
			zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT,'','SSL',true,false));
		}
	} else {
		$messageStack->add_session('checkout_payment',$_ERROR_MESSAGE,'error');
		zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT,'','SSL',true,false));
	}
}
//	Store Data
function after_process() {
	global $db,$insert_id;
	$rows[] = array(
		'orders_id'=>$insert_id,
		'orders_status_id'=>$this->order_status,
		'date_added'=>'now()',
		'customer_notified'=>'-1',
		'comments'=>'Payment was successfully completed with MyGate'
	);
	foreach($rows as $row) {
		$f = implode(", ",array_keys($row));
		$v = implode("', '",array_values($row));
		$db->Execute("INSERT INTO $this->o ($f) VALUES ('$v')");
	}
	return false;
}
//	Create Default osCommerce Functions
function javascript_validation() {
	return false;
}
function selection() {
	return array('id'=>$this->code,'module'=>$this->title);
}
function pre_confirmation_check() {
	return false;
}
function confirmation() {
	return false;
}

}