<?php

	/*MUST BE INSERTED INTO		'//includes/languages/english/modules/payment/'	FOLDER   */

define('MODULE_PAYMENT_MYGATE_TEXT_TITLE', 'MyGate');
define('MODULE_PAYMENT_MYGATE_TEXT_DESCRIPTION', 'Welcome to the MyGate Payment Gateway Configuration');
define('MODULE_PAYMENT_MYGATE_TEXT_ERROR', 'An error has occured');

?>
