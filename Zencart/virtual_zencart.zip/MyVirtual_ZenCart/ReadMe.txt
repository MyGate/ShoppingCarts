##################################################################################
   Document                  : MyGate South Africa OSCommerce Payment Module
   Version                   : 1.0
   Original Author           : Steven Ellis, MyGate
   Last modification date    : 26-Apr-2007
##################################################################################
   History:
   2006-04-26		     : v1.0
##################################################################################

---------------------------------------------------------------------------------------------------------------

In order to integrate the MyGate VIRTUAL Payment Gateway into Zencart, please copy the following three files to their respective locations:
1	'mygate.php' to '//includes/modules/payment/' folder
2	'mygate.php' to '/catalog/includes/languages/english/modules/payment/' folder
3	'checkout_mygate_success.php' to the root folder


Please make sure that you have writing privileges to the following file: '\\admin\modules.php', otherwise you will receive an error when opening the payment-gateway-list page in your browser.


Once the files are sitting in their correct location, go to 'http://localhost/zancart/admin/' (or wherever your Zencart application is sitting), and click on the 'Modules -> 'Payment' link. Enable the MyGate Payment Module by selecting MyGate from the list of modules and clicking the 'Install' button.


Once enabled, edit the MyGate Payment Module and set the correct fields:

	1. Enable / disable the MyGate Module

	2. MyGate Mode: 0 = test mode; 1 = live mode

	3. MerchantID (your MerchantID as allocated by MyGate)

	4. ApplicationID (your ApplicationID as allocated by MyGate)

	5. The 'successful' and 'failed' redirect URLs (i.e., to which URL must MyGate redirect in a successful or failed transaction). 
	This is be fedault set to http://localhost/zencart/checkout_mygate_success.php, but must be changed to reflect your correct zencart URL eg. 			'http://www.MyZencart_Site/checkout_mygate_success.php'.


Once these fields have been updated, test the connection to MyGate by purchasing an item on your Zencart site and performing the payment through the MyGate gateway.
Use the following fields to performing a test transaction:

	Card Name			Joe Soap
	Card Number (No spaces) 	4111111111111111
	Card Type 			Visa
	Card Expiry Date 		Any time in the future
	CCV Number 			123

If you see the following error when you submit your form to MyGate:

	'ERROR: You do not have permission to use this system.'

this means that your website's Form URL has not recognised by MyGate, or that your MerchantID and/or ApplicationID is/are incorrect. Please contact 	MyGate to rectify this.



  