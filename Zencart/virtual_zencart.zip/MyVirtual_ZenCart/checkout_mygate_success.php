<?php
/*
 	$Id: checkout_mygate_success.php,v 1 2007/04/26 $
 	Steven Ellis, MyGate 
  	Copyright (c) 2007 MyGate
	Released under the GNU General Public License
	
	THIS PAGE IS USED TO REDIRECT THE ZENCART PAYMENT PROCESS TO THE CORRECT PAGE, ONCE PAYMENT HAS BEEN PROCESSED.
	IN THE CASE WHERE NO ERROR WAS RETURNED, REDIRECT THE TRANSACTION TO THE CHECKOUT PAGE,
	OTHERWISE RETURN TO THE PAYMENT PAGE AND DISPLAY THE ERROR MESSAGE TO THE END-USER.
	
	MUST BE INSERTED INTO THE ROOT FOLDER OF THE ZENCART APLICATION, alongside other files like 'index.php' etc.
	 
*/

	require('includes/application_top.php');
	
	//required to restore the session
	$session_name = $_POST['VARIABLE1'];	
	
	//variablise the results of the transaction (posted back from MyGate URL)
	$_result=$_POST['_RESULT'];
	$_error_code=$_POST['_ERROR_CODE'];
	$_error_source=$_POST['_ERROR_SOURCE'];
	$_error_message=$_POST['_ERROR_MESSAGE'];
	$_error_detail=$_POST['_ERROR_DETAIL'];
	
	if ($_result >= 0)
	{	
		//SUCCESS!!
		zen_redirect(zen_href_link(FILENAME_CHECKOUT_PROCESS, zen_session_id() . '=' . $session_name . '&payment_error=&ERR=', 'SSL', true, false));
  	}
	else if ($_result < 0)
	{
		//FAILURE!!
		//add the error description to the message stack
		$messageStack->add_session('checkout_payment', urldecode($_error_detail), 'error');	
			
		zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, zen_session_id() . '=' . $session_name . '&payment_error=', 'SSL', true, false));      
	}
?>