Included Files For Integration

In the file which you down loaded, there are three sub folders, �includes�, �store� and �backofficelite�. Please make sure that you make a backup of your Comersus directory before you proceed with the steps listed below. In order for Comersus to work with MyGate, you need to copy the above mentioned folders and complete the following:

Step 1:
	
Copy the folder named �includes� and paste it in the directory where you have installed Comersus. It will prompt you whether you want to overwrite the current folder, click on YES.

Step 2:

Copy the folder named �store� and paste it into the directory where you installed Comersus. It will prompt you again whether you want to overwrite the current folder, click on YES.

Step 3:

Copy the folder named �backofficelite� and paste it into the directory where you installed Comersus. It will again prompt you whether you want to overwrite the current folder, click on YES.

Step 4:

Open your web browser and run the asp file named �comersus_databaseInsert.asp� which you copied into the �includes� folder in Step 1. Remember that you must run it from the directory where you installed Comersus and not from the file which you were sent or downloaded from MyGate.

Running this asp file updates your database with the information that MyGate needs to complete the secure transaction. It adds the Mode, MerchantID, ApplicationID, SuccessfulURL, and the FailureURL, as well as a payment method called �Credit Card (MyGate)� when the user chooses a payment option, he/she must choose this payment method.


Once you have completed steps 1 � 4, you are now ready to use MyGate as a payment gateway.

When you log into the admin side, and go to utilities ->Settings, there will be 5 fields at the bottom which you can change. You must edit the MerchantID and ApplicationID to match the ones that MyGate provided you in an email. If you want to conduct test transactions, you can leave the mode to �Testing�. 
If you wish to conduct Live transactions, you can change the mode to �Live� and click on the �Save� button. The Success URL and the Failure URL are also changeable, however, the asp file specified in the default SuccessURL and FailureURL fields will work on your local computer in test mode. You can edit them to work with your website in Live mode if you wish by changing the path name in the URL.
