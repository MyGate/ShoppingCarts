<?php

//	Copyright 2012 MyGate

//	Extract $_POST
extract($_POST);
//	Redirect to MyGate $_RESULT isn't defined
if(!$_RESULT) {
	//	Prevent Direct Access
	if(!defined('XCART_START')) {
		header('Location: ../');
		exit;
	}
	//	Create Variables
	$ids = join('-',$secure_oid);
	$action = 'https://www.mygate.co.za/virtual/8x0x0/dsp_ecommercepaymentparent.cfm';
	if($module_params['testmode']=='Y') {
		$mode = '0';
		$merchant = '79958a8d-0c7b-4038-8e2e-8948e1d678e1';
		$application = 'd48750f9-1dc0-4290-a94c-9a1c9f7e2fb1';
	} else {
		$mode = '1';
		$merchant = $module_params['param01'];
		$application = $module_params['param02'];
	}
	$reference = sprintf("%010d",$ids);
	$price = $cart['total_cost'];
	$currency = 'ZAR';
	$url = $http_location.'/payment/cc_mygate.php';
	//	Add Order to DB
	db_query("REPLACE INTO $sql_tbl[cc_pp3_data] (ref, sessionid) VALUES ('$ids', '$XCARTSESSID')");
	//	Create POST
	$post = array(
		'Mode'=>$mode,
		'txtMerchantID'=>$merchant,
		'txtApplicationID'=>$application,
		'txtMerchantReference'=>$reference,
		'txtPrice'=>$price,
		'txtCurrencyCode'=>$currency,
		'txtRedirectSuccessfulURL'=>$url,
		'txtRedirectFailedURL'=>$url,
		'Variable1'=>$ids
	);
	//	Create Form
	func_create_payment_form($action,$post,'MyGate');
	//	Exit
	exit;
}
//	Capture Payment if $_RESULT is defined
if($_RESULT) {
	//	Require auth.php
	require './auth.php';
	//	Get Transaction Details
	$session = func_query_first("SELECT * FROM $sql_tbl[cc_pp3_data] WHERE ref = '$VARIABLE1'");
	$order = func_query_first("SELECT * FROM $sql_tbl[orders] WHERE orderid = '$session[ref]'");
	//	Create Variables
	$bill_output['sessid'] = $session['sessionid'];
	//	Check $_RESULT
	if($_RESULT > -1)
		if($TXTPRICE == $order['total'])
			$bill_output['code'] = 1;
		else {
			$bill_output['code'] = 2;
			$bill_output['billmes'] = "Payment was not completed with MyGate\n";
			$bill_output['billmes'].= "Error Message: Payment Details were altered before being sent to MyGate\n";
		}
	else {
		$bill_output['code'] = 2;
		$bill_output['billmes'] = "Payment was not completed with MyGate\n";
		$bill_output['billmes'].= "Error Code: $_ERROR_CODE\n";
		$bill_output['billmes'].= "Error Source: $_ERROR_SOURCE\n";
		$bill_output['billmes'].= "Error Message: $_ERROR_MESSAGE\n";
		$bill_output['billmes'].= "Error Detail: $_ERROR_DETAIL\n";
		if($_BANK_ERROR_CODE)
			$bill_output['billmes'].= "Bank Error Code: $_BANK_ERROR_CODE\n";
		if($_BANK_ERROR_MESSAGE)
			$bill_output['billmes'].= "Bank Error Message: $_BANK_ERROR_MESSAGE\n";
	}
	//	Require payment_ccend.php
	require($xcart_dir.'/payment/payment_ccend.php');
}

?>