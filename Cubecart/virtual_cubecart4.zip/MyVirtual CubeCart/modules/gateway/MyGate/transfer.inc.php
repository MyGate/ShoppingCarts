<?php
/*
//////////////////////////
// MYGATE GATEWAY
//////////////////////////
// IN THE REPEATED REGION
//////
$orderInv['productId']						- product id as an integer
$orderInv['name']							- product name as a varchar
$orderInv['price']							- price of each product (inc options)
$orderInv['quantity']						- quantity of products as an integer
$orderInv['product_options']				- products attributes as test
$orderInv['productCode']					- product code as a varchar
$i											- This is the current incremented integer starting at 0

/////////////////////////
// FIXED VARS
///////
$cart_order_id								- cart order id as a varchar
$ccUserData[0]['email']						- Customers email address

$basket['subTotal'] 					- Order Subtotal (exTax and Shipping)
$basket['grandTotal']					- Basket total which has to be paid (inc Tax and Shipping).
$basket['tax']							- Total tax to pay
$basket['shipCost']						- Shipping price
////////////////////////////////////////////////////////
*/

$module = fetchDbConfig("MyGate");

function repeatVars(){

		return FALSE;
	
}

function fixedVars(){
	
	global $module, $basket, $ccUserData, $cart_order_id, $config, $GLOBALS;
	
	$hiddenVars = "<input type='hidden' name='Mode' value='".$module['Mode']."' />
					<input type='hidden' name='txtMerchantID' value='".$module['MerchantID']."' />
					<input type='hidden' name='txtApplicationID' value='".$module['ApplicationID']."' />
					<input type='hidden' name='txtMerchantReference' value='".$cart_order_id."' />
					<input type='hidden' name='txtPrice' value='".$basket['grandTotal']."' />
					<input type='hidden' name='txtCurrencyCode' value='".$config['defaultCurrency']."' />					
					<input type='hidden' name='txtRedirectSuccessfulURL' value='".$GLOBALS['storeURL']."/confirmed.php?act=conf&amp;&amp;pg=MyGate&amp;oid=".base64_encode($cart_order_id)."'>
					<input type='hidden' name='txtRedirectFailedURL' value='".$GLOBALS['storeURL']."/confirmed.php?act=conf&amp;f=1&amp;&amp;pg=MyGate&amp;oid=".base64_encode($cart_order_id)."'>					
					<input type='hidden' name='Variable1' value='".$cart_order_id."' />";
					
	return $hiddenVars;
	
}

function success(){
		
		global $basket;
	
	if( (base64_decode($_GET['oid']) == $basket['cart_order_id']) && !isset($_GET['f']) ) {
	
		return TRUE;
	
	} else {
	
		return FALSE;
	
	}	

}

///////////////////////////
// Other Vars
////////
$formAction = "https://www.mygate.co.za/virtual/8x0x0/dsp_ecommercepaymentparent.cfm";
$formMethod = "post";
$formTarget = "_self";
$transfer = "auto";
$stateUpdate = TRUE;
?>