##################################################################################
   Document                  : MyGate South Africa OSCommerce Payment Module
   Version                   : 1.0
   Original Author           : Steven Ellis, MyGate
   Last modification date    : 18_Apr-2007
##################################################################################
   History:
   2006-04-18		     : v1.0
##################################################################################

---------------------------------------------------------------------------------------------------------------


In order to integrate the MyGate VIRTUAL Payment Gateway into OSCommerce, please copy the following three files to their respective locations:
1	'mygate.php' to '/catalog/includes/modules/payment/' folder
2	'mygate.php' to '/catalog/includes/languages/english/modules/payment/' folder
3	'checkout_mygate_success.php' to '/catalog/' folder



Please make sure that you have writing privileges to the following file: '\catalog\admin\modules.php', otherwise you will receive an error when opening the payment-gateway-list page in your browser.


Once the files are sitting in their correct location, go to 'http://localhost/oscommerce/catalog/admin/' (or wherever your oscommerce application is sitting), and click on the 'Payment' link. Enable the MyGate Payment Module by selecting MyGate from the list of modules and clicking the 'Install' button.



Once enabled, edit the MyGate Payment Module and set the correct fields:

	MerchantID (your MerchantID as allocated by MyGate)

	ApplicationID (your ApplicationID as allocated by MyGate)

	The 'successful' and 'failed' redirect URLs (i.e., to which URL must MyGate redirect in a successful or failed transaction). In this code example, 	both point to the same page ('checkout_mygate_success.php'), which then itself redirects the application to the correct page, depending on whether or not 		payment was successful. 

	MyGate Mode: 0 = test mode; 1 = live mode

	Transaction Currency



Once these fields have been updated, test the connection to MyGate by purchasing an item on your OsCommerce site and performing the payment through the MyGate gateway.
Use the following fields to performing a test transaction:

	Card Name			Joe Soap
	Card Number (No spaces) 	4111111111111111
	Card Type 			Visa
	Card Expiry Date 		Any time in the future
	CCV Number 			123



If you see the following error when you submit your form to MyGate:

	'ERROR: You do not have permission to use this system.'

this means that your website's Form URL has not recognised by MyGate, or that your MerchantID and/or ApplicationID is/are incorrect. Please contact 	MyGate to rectify this.



  