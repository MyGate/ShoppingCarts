<?php
/*
 	$Id: checkout_mygate_success.php,v 1 2007/04/18 $
 	Steven Ellis, MyGate 
  	Copyright (c) 2007 MyGate
	Released under the GNU General Public License
	
	THIS PAGE IS USED TO REDIRECT THE OSCOMMERCE PAYMENT PROCESS TO THE CORRECT PAGE, ONCE PAYMENT HAS BEEN PROCESSED.
	IN THE CASE WHERE NO ERROR WAS RETURNED, REDIRECT THE TRANSACTION TO THE CHECKOUT PAGE,
	OTHERWISE RETURN TO THE PAYMENT PAGE AND DISPLAY THE ERROR MESSAGE TO THE END-USER.
	
	MUST BE INSERTED INTO THE '/catalog/' FOLDER, alongside other files like 'checkout_payment', 'checkout_process.php' etc.
	 
*/

	require('includes/application_top.php');
	
	//required to restore the session
	$session_name = $_POST['VARIABLE1'];
	
	//variablise the results of the transaction (posted back from MyGate URL)
	$_result=$_POST['_RESULT'];
	$_error_code=$_POST['_ERROR_CODE'];
	$_error_source=$_POST['_ERROR_SOURCE'];
	$_error_message=$_POST['_ERROR_MESSAGE'];
	$_error_detail=$_POST['_ERROR_DETAIL'];
	
	if ($_result >= 0)
	{	
		//SUCCESS!!
		tep_redirect(tep_href_link(FILENAME_CHECKOUT_PROCESS, tep_session_name() . '=' . $session_name . '&payment_error=&ERR=', 'SSL', false, false));
  	}
	else if ($_result < 0)
	{
		//FAILURE!!
		 tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, tep_session_name() . '=' . $session_name . '&error_message=' . urlencode($_error_detail), 'SSL', false, false));      
	}
	
 ?>