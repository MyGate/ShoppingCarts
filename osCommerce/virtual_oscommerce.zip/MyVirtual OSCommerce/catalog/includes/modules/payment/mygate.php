<?php

/*
 	$Id: mygate.php,v 1 2007/04/18 $
 	Steven Ellis, MyGate 
  	Copyright (c) 2007 MyGate
	Released under the GNU General Public License
	
	THIS PAGE IS USED TO PROCESS ONLINE PAYMENTS THROUGH THE 
	MYGATE PAYMENT GATEWAY.
	
	PLEASE NOTE THE FOLLOWING:
	-	The Merchant reference is composed of the CustomerID concatenated with a 'dash' (-) and the date and time of the transaction
	-	The Session information MUST be passed to the MyGate payment URL in the 'Variable1' form variable, as this is posted back to the OsCommerce application to allow the transaction to continue
	
	MUST BE INSERTED INTO		'/catalog/includes/modules/payment/'	FOLDER   
	
*/

  class mygate {
    var $code, $title, $description, $enabled, $errortext;

// class constructor
    function mygate() {
      global $order;


      $this->code = 'mygate';
	  $this->title = MODULE_PAYMENT_MYGATE_TEXT_TITLE;
      $this->description = MODULE_PAYMENT_MYGATE_TEXT_DESCRIPTION;
      $this->enabled = ((MODULE_PAYMENT_MYGATE_STATUS == 'True') ? true : false);

      if ((int)MODULE_PAYMENT_MYGATE_ORDER_STATUS_ID > 0) {
        $this->order_status = MODULE_PAYMENT_MYGATE_ORDER_STATUS_ID;
      }

      $this->form_action_url = 'https://www.mygate.co.za/virtual/8x0x0/dsp_ecommercepaymentparent.cfm';
	  
    }

// class methods
  
    function javascript_validation() {
      return false;
    }

    function selection() {
      return array('id' => $this->code,
                   'module' => $this->title);
    }

    function pre_confirmation_check() {
		return false;
    }

    function confirmation() {
		return false;
    }

    function process_button() 
	{		
	
      global $order, $currencies, $currency, $customer_id;

      switch (MODULE_PAYMENT_MYGATE_CURRENCY) {
        case 'Default Currency':
          $sec_currency = DEFAULT_CURRENCY;
          break;
        case 'Any Currency':
        default:
          $sec_currency = $currency;
          break;
      }	 
	 $process_button_string = tep_draw_hidden_field('txtMerchantID', MODULE_PAYMENT_MYGATE_MERCHANT_ID).
		                        tep_draw_hidden_field('txtApplicationID', MODULE_PAYMENT_MYGATE_APPLICATION_ID).   	
								tep_draw_hidden_field('txtMerchantReference', $customer_id . "-" . date("ymdHi")).
								tep_draw_hidden_field('Mode', MODULE_PAYMENT_MYGATE_MODE).
								tep_draw_hidden_field('Variable1', $_REQUEST[tep_session_name()]).	
								tep_draw_hidden_field('txtRedirectFailedURL', MODULE_PAYMENT_MYGATE_FAILED_URL).					   
                               tep_draw_hidden_field('txtDisplayPrice', number_format($order->info['total'] * $currencies->get_value($sec_currency), $currencies->currencies[$sec_currency]['decimal_places'], '.', '')).
							   tep_draw_hidden_field('txtPrice', number_format($order->info['total'] * $currencies->get_value('ZAR'), $currencies->currencies[$sec_currency]['decimal_places'], '.', '')).
                               tep_draw_hidden_field('txtCurrencyCode', 'ZAR').
							   tep_draw_hidden_field('txtDisplayCurrencyCode', $sec_currency).
                               tep_draw_hidden_field('txtRedirectSuccessfulURL', MODULE_PAYMENT_MYGATE_SUCCESSFUL_URL);
							                            

		//if(number_format($order->info['total'] * $currencies->get_value($sec_currency), $currencies->currencies[$sec_currency]['decimal_places'], '.', '') <= "5000.00")
		//{
			return $process_button_string;
		//}
		//else
		//{
		//	echo("Maximum rand value limit reached. Transaction value cannot exceed R5000.00. Please try again.");
		//}
	  
    }

    function before_process() 
	{	
		
    }

    function after_process() {
		return false;
    }

    function get_error() {
	
      global $HTTP_GET_VARS;

      $error = array('title' => MODULE_PAYMENT_MYGATE_TEXT_ERROR,
                     'error' => stripslashes(urldecode($HTTP_GET_VARS['error'])));

      return $error;
    }

    function check() {
      if (!isset($this->_check)) {
        $check_query = tep_db_query("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_MYGATE_STATUS'");
        $this->_check = tep_db_num_rows($check_query);
      }
      return $this->_check;
    }

    function install() {

      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable MyGate Module', 'MODULE_PAYMENT_MYGATE_STATUS', 'True', 'Do you want to accept MyGate payments?', '6', '1', 'tep_cfg_select_option(array(\'True\', \'False\'), ', now())");
	  
	   tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('MyGate Mode', 'MODULE_PAYMENT_MYGATE_MODE', '1', 'Mode Settings: 0 = Test Mode; 1 = Live Mode', '6', '2', 'tep_cfg_select_option(array(\'0\', \'1\'), ', now())");
	  
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Merchant ID', 'MODULE_PAYMENT_MYGATE_MERCHANT_ID', '79958a8d-0c7b-4038-8e2e-8948e1d678e1', 'Merchant ID to use for the MyGate service', '6', '3', now())");
	  
	  tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Application ID', 'MODULE_PAYMENT_MYGATE_APPLICATION_ID', 'd48750f9-1dc0-4290-a94c-9a1c9f7e2fb1', 'Application ID to use for the MyGate service', '6', '4', now())");
	  
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Transaction Currency', 'MODULE_PAYMENT_MYGATE_CURRENCY', 'Default Currency', 'The currency to use for credit card transactions', '6', '5', 'tep_cfg_select_option(array(\'Any Currency\', \'Default Currency\'), ', now())");
	  
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Redirect Successful URL', 'MODULE_PAYMENT_MYGATE_SUCCESSFUL_URL', 'http://localhost/oscommerce/catalog/checkout_mygate_success.php', 'The URL to redirect when the transaction is successful', '6', '6', now())");
	  
	 tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Redirect Failed URL', 'MODULE_PAYMENT_MYGATE_FAILED_URL', 'http://localhost/oscommerce/catalog/checkout_mygate_success.php', 'The URL to redirect when the transaction has failed', '6', '7', now())");	  
	  
    }

    function remove() {
      tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }

    function keys() {
      return array('MODULE_PAYMENT_MYGATE_STATUS', 'MODULE_PAYMENT_MYGATE_MODE', 'MODULE_PAYMENT_MYGATE_MERCHANT_ID', 'MODULE_PAYMENT_MYGATE_APPLICATION_ID','MODULE_PAYMENT_MYGATE_CURRENCY', 'MODULE_PAYMENT_MYGATE_SUCCESSFUL_URL', 'MODULE_PAYMENT_MYGATE_FAILED_URL');
    }
  }
?>
