<?php

	/*MUST BE INSERTED INTO		'/catalog/includes/languages/english/modules/payment/'	FOLDER   */

  define('MODULE_PAYMENT_MYGATE_TEXT_TITLE', 'Credit Card Payment via MyGate');
  define('MODULE_PAYMENT_MYGATE_TEXT_DESCRIPTION', 'Welcome to the MyGate Payment Gateway Configuration');

?>