<?php

//	Copyright 2012 MyGate

//	Create MyGate Class
class mygate {
//	Create Constructor Function
function mygate() {
	global $order;
	//	Create Module Settings
	$this->enabled = (MODULE_PAYMENT_MYGATE_STATUS == 'Yes') ? true : false;
	$this->code = 'mygate';
	$this->signature = 'mygate|mygate|1.0|1.0';
	//	Create MyGate Settings
	$this->title = MODULE_PAYMENT_MYGATE_TEXT_TITLE;
	$this->description = MODULE_PAYMENT_MYGATE_TEXT_DESCRIPTION;
	$this->sort_order = MODULE_PAYMENT_MYGATE_SORT;
	$this->order_status = 2;
	$this->public_title = MODULE_PAYMENT_MYGATE_TEXT_PUBLIC_TITLE;
	$this->form_action_url = 'https://www.mygate.co.za/virtual/8x0x0/dsp_ecommercepaymentparent.cfm';
	//	Create Table Variable
	$this->t = TABLE_CONFIGURATION;
}
//	Create Check Function
function check() {
	return ($this->_check) ? $this->_check : tep_db_num_rows(tep_db_query("SELECT configuration_value FROM $this->t WHERE configuration_key = 'MODULE_PAYMENT_MYGATE_STATUS'"));
}
//	Create Install Function
function install() {
	$rows[] = array(
		'configuration_title'=>'Enabled?',
		'configuration_key'=>'MODULE_PAYMENT_MYGATE_STATUS',
		'configuration_value'=>'No',
		'configuration_description'=>'Select "Yes" to start accepting payments with your MyGate Account.',
		'configuration_group_id'=>'6',
		'sort_order'=>'0',
		'set_function'=>'tep_cfg_select_option(array(\"Yes\", \"No\"), '
	);
	$rows[] = array(
		'configuration_title'=>'Test Mode?',
		'configuration_key'=>'MODULE_PAYMENT_MYGATE_MODE',
		'configuration_value'=>'Yes',
		'configuration_description'=>'Select "Yes" to process transaction in Test Mode.',
		'configuration_group_id'=>'6',
		'sort_order'=>'0',
		'set_function'=>'tep_cfg_select_option(array(\"Yes\", \"No\"), '
	);
	$rows[] = array(
		'configuration_title'=>'MyGate Merchant ID',
		'configuration_key'=>'MODULE_PAYMENT_MYGATE_MID',
		'configuration_description'=>'Type the "Merchant ID" allocated to you by MyGate.',
		'configuration_group_id'=>'6',
		'sort_order'=>'0'
	);
	$rows[] = array(
		'configuration_title'=>'MyGate Application ID',
		'configuration_key'=>'MODULE_PAYMENT_MYGATE_AID',
		'configuration_description'=>'Type the "Application ID" allocated to you by MyGate.',
		'configuration_group_id'=>'6',
		'sort_order'=>'0'
	);
	$rows[] = array(
		'configuration_title'=>'Sort Order',
		'configuration_key'=>'MODULE_PAYMENT_MYGATE_SORT',
		'configuration_value'=>'0',
		'configuration_description'=>'Type the "Sort Order" of MyGate in relation to other Payment Gateways.',
		'configuration_group_id'=>'6',
		'sort_order'=>'0'
	);
	foreach($rows as $row) {
		$f = implode(", ",array_keys($row));
		$v = implode("', '",array_values($row));
		tep_db_query("INSERT INTO $this->t ($f) VALUES ('$v')");
	}
}
//	Create Keys Function
function keys() {
	return array('MODULE_PAYMENT_MYGATE_STATUS','MODULE_PAYMENT_MYGATE_MODE','MODULE_PAYMENT_MYGATE_MID','MODULE_PAYMENT_MYGATE_AID','MODULE_PAYMENT_MYGATE_SORT');
}
//	Create Remove Function
function remove() {
	tep_db_query("DELETE FROM $this->t WHERE configuration_key LIKE '%MYGATE%'");
}
//	Create Process Button
function process_button() {
	global $customer_id,$order,$currency,$cartID;
	//	Create Variables
	if(MODULE_PAYMENT_MYGATE_MODE == 'Yes') {
		$mode = '0';
		$merchant = '79958a8d-0c7b-4038-8e2e-8948e1d678e1';
		$application = 'd48750f9-1dc0-4290-a94c-9a1c9f7e2fb1';
	} else {
		$mode = '1';
		$merchant = MODULE_PAYMENT_MYGATE_MID;
		$application = MODULE_PAYMENT_MYGATE_AID;
	}
	$reference = sprintf("%010d",$cartID);
	$price = number_format($order->info['total'],2,'.','');
	$currency = 'ZAR';
	$surl = tep_href_link(FILENAME_CHECKOUT_PROCESS,tep_session_name().'='.tep_session_id(),'SSL',false);
	$furl = tep_href_link(FILENAME_CHECKOUT_PAYMENT,'payment_error='.$this->code,'SSL',false);
	//	Create POST
	$post = array(
		'Mode'=>$mode,
		'txtMerchantID'=>$merchant,
		'txtApplicationID'=>$application,
		'txtMerchantReference'=>$reference,
		'txtPrice'=>$price,
		'txtCurrencyCode'=>$currency,
		'txtRedirectSuccessfulURL'=>$surl,
		'txtRedirectFailedURL'=>$furl
	);
	//	Create Fields
	foreach($post as $k=>$v)
		$button.= tep_draw_hidden_field($k,$v);
	//	Return Button
	return $button;
}
//	Capture Payment
function before_process() {
	global $order;
	//	Extract $_POST
	extract($_POST);
	//	Check $_RESULT
	$total = number_format($order->info['total'],2,'.','');
	if($_RESULT > -1 && $TXTPRICE == $total)
		$order->info['comments'] = 'Payment was successfully completed with MyGate';
	else
		tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT,'payment_error='.$this->code.'&error='.$_ERROR_MESSAGE,'SSL'));
}
function after_process() {
	return false;
}
//	Create Default osCommerce Functions
function javascript_validation() {
	return false;
}
function selection() {
	return array('id'=>$this->code,'module'=>$this->public_title);
}
function pre_confirmation_check() {
	return false;
}
function confirmation() {
	return false;
}
function get_error() {
	global $order;
	//	Extract $_POST
	extract($_POST);
	//	Check $_RESULT
	$total = number_format($order->info['total'],2,'.','');
	if($TXTPRICE != $total)
		$error = 'Payment Details were altered before being sent to MyGate';
	else
		$error = MODULE_PAYMENT_MYGATE_ERROR_GENERAL;
	//	Return Error
	return array(
		'title' => MODULE_PAYMENT_MYGATE_ERROR_TITLE,
		'error' => $error
	);
}

}

?>